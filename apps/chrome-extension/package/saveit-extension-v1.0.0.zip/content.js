"use strict";(()=>{var E="https://saveit.now";var k="hidden",n="page",y="";async function h(){return new Promise(e=>{chrome.runtime.sendMessage({type:"GET_SESSION"},t=>{console.log("Content: Session response from background",t),e(t?.session||null)})})}async function p(e,t="page"){return new Promise(r=>{chrome.runtime.sendMessage({type:"SAVE_BOOKMARK",url:e,itemType:t},a=>{console.log("Content: Save response from background",a),r(a||{success:!1,error:"No response from background",itemType:t})})})}function c(e){switch(e){case"page":return"page";case"link":return"link";case"image":return"image";default:return"item"}}function d(){let e=document.createElement("div");return e.id="saveit-now-container",e.className="saveit-container hidden",e.innerHTML=`
    <div class="saveit-card">
      <div id="saveit-loading" class="saveit-state">
        <svg class="saveit-loader" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-loader-circle-icon lucide-loader-circle"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
        <div id="saveit-loading-message" class="saveit-message">Saving...</div>
      </div>
      
      <div id="saveit-success" class="saveit-state">
        <svg class="saveit-checkmark" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-check-icon lucide-check"><path d="M20 6 9 17l-5-5"/></svg>
        <div id="saveit-success-message" class="saveit-message">Page saved!</div>
      </div>
      
      <div id="saveit-error" class="saveit-state">
        <svg class="saveit-error" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-circle-alert-icon lucide-circle-alert"><circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/></svg>
        <div class="saveit-message" id="saveit-error-message">An error occurred</div>
      </div>
      
      <div id="saveit-auth" class="saveit-state saveit-auth-required">
        <div class="saveit-message">Please login to save bookmarks</div>
        <a href="${E}/signin" target="_blank" class="saveit-button">Login</a>
      </div>

      <div id="saveit-max-bookmarks" class="saveit-state saveit-auth-required">
        <div class="saveit-message">Bookmark limit reached. Upgrade to save more!</div>
        <a href="${E}/upgrade" target="_blank" class="saveit-button">Upgrade</a>
      </div>

      <div id="saveit-bookmark-exists" class="saveit-state">
        <svg class="saveit-error" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/></svg>
        <div class="saveit-message">This bookmark already exists in your collection</div>
      </div>
    </div>
  `,document.body.appendChild(e),document.addEventListener("click",t=>{e&&!e.contains(t.target)&&k!=="hidden"&&s("hidden")}),e}function s(e){k=e;let t=document.getElementById("saveit-now-container");if(!t)return;switch(t.querySelectorAll(".saveit-state").forEach(a=>{a.style.display="none"}),e){case"hidden":t.classList.add("hidden");break;case"loading":t.classList.remove("hidden");let a=document.getElementById("saveit-loading");a&&(a.style.display="flex");let o=document.getElementById("saveit-loading-message");o&&(o.textContent=`Saving ${c(n)}...`);break;case"success":t.classList.remove("hidden");let i=document.getElementById("saveit-success");i&&(i.style.display="flex");let v=document.getElementById("saveit-success-message");v&&(v.textContent=`${c(n).charAt(0).toUpperCase()+c(n).slice(1)} saved!`),setTimeout(()=>{s("hidden")},2400);break;case"error":t.classList.remove("hidden");let u=document.getElementById("saveit-error");u&&(u.style.display="flex"),setTimeout(()=>{s("hidden")},4800);break;case"auth-required":t.classList.remove("hidden");let m=document.getElementById("saveit-auth");m&&(m.style.display="flex");break;case"max-bookmarks":t.classList.remove("hidden");let S=document.getElementById("saveit-max-bookmarks");S&&(S.style.display="flex");break;case"bookmark-exists":t.classList.remove("hidden");let g=document.getElementById("saveit-bookmark-exists");g&&(g.style.display="flex"),setTimeout(()=>{s("hidden")},3600);break}}function l(e){let t=document.getElementById("saveit-error-message");t&&(t.textContent=e)}async function f(e,t="page"){try{if(n=t,y=e,s("loading"),!await h()){s("auth-required");return}let a=await p(e,t);if(a.success)s("success");else{let o=a.errorType,i=a.error||"Error saving bookmark";switch(o){case"BOOKMARK_ALREADY_EXISTS":s("bookmark-exists");break;case"MAX_BOOKMARKS":s("max-bookmarks");break;case"AUTH_REQUIRED":s("auth-required");break;case"NETWORK_ERROR":l("Network error. Please check your connection."),s("error");break;default:i.includes("maximum number of bookmarks")?s("max-bookmarks"):i.includes("already exists")?s("bookmark-exists"):i.includes("logged in")?s("auth-required"):(l(i),s("error"));break}}}catch(r){console.error("Error saving content:",r),l("An unexpected error occurred"),s("error")}}chrome.runtime.onMessage.addListener((e,t,r)=>{if(document.getElementById("saveit-now-container")===null&&d(),e.action==="saveBookmark"||e.action==="showSaveUI"){let a=e.type?e.type:"page",o=e.url||window.location.href;f(o,a),r({status:"received"})}});document.addEventListener("DOMContentLoaded",()=>{d()});(document.readyState==="complete"||document.readyState==="interactive")&&d();})();
